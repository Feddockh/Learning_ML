# Hayden Feddock
# 3/30/2023

import numpy as np

# Function to compute the sigmoid
def sigmoid(z):
    return 1 / (1 + np.exp(-z))
